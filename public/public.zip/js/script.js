$(document).ready(function() {
    $('#alerta-pedido').click( function() {
        $('#alerta-pedido').show('fade');
    });
});